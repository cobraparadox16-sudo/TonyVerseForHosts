# Server Pulse

A server status page: edit CPU, memory, disk, network and uptime metrics, keep a live log, and republish the page.

## What's in this zip

`index.html`, the whole project in one file, and this README.

## Open it

It is a single self-contained page. Open `index.html` in any modern browser. For a more realistic test, serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Put it on GitHub Pages

1. Create a new GitHub repository and upload the contents of this zip (not the zip itself).
2. Go to **Settings > Pages**, set Source to **Deploy from a branch**, choose `main` and `/ (root)`, and save.
3. After a minute or two it is live at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

## Notes

- **Saved data stays in your browser.** Progress and settings are stored in this browser only, so they won't carry across devices or browsers.
- **Some features need Claude's hosted runtime.** This page calls `window.claude` (for example shared data, saving or AI features). Outside claude.ai that object doesn't exist, so those parts won't work or will only keep data on the current device.
- **Needs an internet connection** for web fonts and any CDN libraries it loads.
- **Original.** Published as a Claude artifact: https://claude.ai/artifact/4roVijK8M2onwqowzCPsyK
