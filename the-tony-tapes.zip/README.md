# The Tony Tapes

An album page of original AI-generated, royalty-free tracks (side A, 6 tracks) with a player. The audio is embedded in the page.

## What's in this zip

`index.html`, the whole project in one file, and this README.

## Open it

It is a single self-contained page. Open `index.html` in any modern browser. For a more realistic test, serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Put it on GitHub Pages

1. Create a new GitHub repository and upload the contents of this zip (not the zip itself).
2. Go to **Settings > Pages**, set Source to **Deploy from a branch**, choose `main` and `/ (root)`, and save.
3. After a minute or two it is live at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

## Notes

- **Saved data stays in your browser.** Progress and settings are stored in this browser only, so they won't carry across devices or browsers.
- **Needs an internet connection** for web fonts and any CDN libraries it loads.
- **Large file.** Images and audio are embedded in `index.html`, so it is big. Before putting it on GitHub, consider splitting them out into an `assets/` folder.
- **Original.** Published as a Claude artifact: https://claude.ai/artifact/TvxymTM8UJg8vTDNn31JLo
